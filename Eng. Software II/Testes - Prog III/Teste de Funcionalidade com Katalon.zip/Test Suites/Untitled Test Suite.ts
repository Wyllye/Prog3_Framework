<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Untitled Test Suite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>302e98f7-79de-4c73-b298-f38cb54cdcd5</testSuiteGuid>
   <testCaseLink>
      <guid>d08cfac8-afd9-4875-ab5f-a67dc70c28e4</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Untitled Test Suite/Cadastro de Produto</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    